#include “Payment.h”
#include “Oder.h”
#include “Feedback.h”
#include <string>
#define SIZE 5;
class RegisteredUser : public RegisteredUser {
 int UID;
 string Upassowrd;
 string Username;
Payment * payment[SIZE];
Order * orders[SIZE];
Feedback * feedback[SIZE];
 public:
RegisteredUser();
RegisteredUser(int pUID,string pUPassowrd, string pUsername);
void login(string username, string password);
void MakePayment();
void EditProfile();
void PlaceOrder();
void SendFeedback();
void viewUserDetails();
~RegisteredUser();
}