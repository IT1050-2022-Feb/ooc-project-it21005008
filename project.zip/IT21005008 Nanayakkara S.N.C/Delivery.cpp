#include <iostream>
#include<string> 
using namespace std;
#include "Delivery.h"
Delivery::Delivery() {
cout << "Default Constructor Delivery() called" << endl;
}
Delivery::) Delivery(int pDeliveryID,string pDeliveryAddress,string pDeliveryTime);
{
int DeliveryID;
 string DeliveryAddress;
 string Dpayment;
srting DeliveryTime;
}
Delivery::~Delivery()
{
 cout << "Destructed" << endl;
}