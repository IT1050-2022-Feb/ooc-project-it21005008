#include <iostream>
#include<string> 
using namespace std;
#include "RegisteredUser.h"
RegisteredUser::RegisteredUser() {
cout << "Default Constructor RegisteredUser() called" << endl;
}
RegisteredUser:: RegisteredUser(int pUID,string pUPassowrd, string pUsername);
{
UID=pUID;
Username= pUPassowrd;
Upassowrd= pUsername;
}
RegisteredUser::~RegisteredUser()
{
cout << "Destructed" << endl;
}