#include <iostream>
#include<string> 
using namespace std;
class Delivery {
 private:
 int DeliveryID;
 string DeliveryAddress;
 string Dpayment;
string DeliveryTime;
 public:
 Delivery();
 Delivery(int pDeliveryID,string pDeliveryAddress,string 
pDeliveryTime);
 void DisplayDeliveryDetails();
 ~Delivery();
};