#include <string>
#define SIZE[10];
#include"Registeruser.h"
#include"Payment.h"
#include"Delivery.h"
#include"item.h"
class Order{
private:
int OrderID;
string OrderDate;
string TotalAmount;
RegisterUser *reg;
Delivery *del;
Payment *p;
Item *items[10];
public:
Order();
Order(int OrderID,string pOrderDate,string pTotalAmount);
void OrderDetails();
};