#include<iostream>
using namespace std;
#include <string>
#include"Order.h"
Order::Order()
{
 cout << "Default Constructor Order() called" << endl;
}
Order::Order(int pOrderID,string 
pOrderDate,string pTotalAmount)
{
 OrderID=pOrderID;
 OrderDate=pOrderDate;
 TotalAmount=pTotalAmount;
}
Order::~Order()
{
cout << "Destructed" << endl;
}